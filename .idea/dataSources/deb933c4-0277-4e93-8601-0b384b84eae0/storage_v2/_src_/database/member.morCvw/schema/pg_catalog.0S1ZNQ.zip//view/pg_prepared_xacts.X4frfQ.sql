create view pg_prepared_xacts(transaction, gid, prepared, owner, database) as
SELECT p.transaction,
       p.gid,
       p.prepared,
       u.rolname AS owner,
       d.datname AS database
FROM pg_prepared_xact() p(transaction, gid, prepared, ownerid, dbid)
         LEFT JOIN pg_authid u ON p.ownerid = u.oid
         LEFT JOIN pg_database d ON p.dbid = d.oid;

alter table pg_prepared_xacts
    owner to rdsadmin;

grant select on pg_prepared_xacts to public;

